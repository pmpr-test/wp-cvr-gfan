<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f86324adc             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');

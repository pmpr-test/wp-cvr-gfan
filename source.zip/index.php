<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d33657e4             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4247ea39e             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');

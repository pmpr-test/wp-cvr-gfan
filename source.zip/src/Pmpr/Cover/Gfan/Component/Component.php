<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db14a60dca             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component; use Pmpr\Cover\Gfan\Component\Module\Contact; use Pmpr\Cover\Gfan\Container; class Component extends Container { public function mameiwsayuyquoeq() { Contact::symcgieuakksimmu(); } }

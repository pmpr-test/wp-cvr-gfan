<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fa3e81             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Component; use Pmpr\Cover\Gfan\Component\Module\Module; use Pmpr\Cover\Gfan\Container; class Component extends Container { public function mameiwsayuyquoeq() { Module::symcgieuakksimmu(); } }

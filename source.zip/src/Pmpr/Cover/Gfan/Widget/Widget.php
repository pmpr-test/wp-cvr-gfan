<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192950bd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Cover\Gfan\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); About::symcgieuakksimmu(); Company::symcgieuakksimmu(); Whatsapp::symcgieuakksimmu(); } }

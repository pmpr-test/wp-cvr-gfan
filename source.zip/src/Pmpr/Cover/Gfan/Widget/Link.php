<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfb3fb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\151\156\153\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\x6c\141\x79\x20\x74\150\x65\40\x73\145\x6c\x65\143\164\145\144\40\154\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\145\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

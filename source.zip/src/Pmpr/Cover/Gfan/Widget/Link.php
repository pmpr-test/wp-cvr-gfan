<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e67d7d9984             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\x69\x6e\x6b\163", PR__CVR__GFAN), __("\104\151\x73\160\x6c\141\171\40\x74\x68\x65\40\163\145\154\145\143\164\x65\144\x20\154\x69\156\x6b\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\x6d\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

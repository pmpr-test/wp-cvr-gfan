<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671248b87ce08             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\x73", PR__CVR__GFAN), __("\x44\151\163\160\x6c\141\x79\x20\164\150\145\x20\x73\x65\154\x65\x63\x74\x65\144\40\x6c\151\156\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

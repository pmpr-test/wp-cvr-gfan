<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e600056ce2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\x69\156\x6b\x73", PR__CVR__GFAN), __("\104\151\x73\160\x6c\x61\171\40\164\150\145\x20\x73\145\154\x65\x63\164\145\x64\40\x6c\x69\x6e\153\x73\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\x65\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

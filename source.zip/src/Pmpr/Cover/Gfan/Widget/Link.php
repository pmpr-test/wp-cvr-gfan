<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192950bd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\x4c\x69\x6e\x6b\163", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\141\171\x20\164\150\x65\x20\x73\x65\154\145\x63\x74\145\144\40\x6c\x69\x6e\153\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\145\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

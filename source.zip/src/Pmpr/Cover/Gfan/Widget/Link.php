<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b9b5ea101             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\x69\x6e\x6b\163", PR__CVR__GFAN), __("\104\151\163\x70\x6c\x61\x79\x20\164\150\x65\x20\163\145\154\x65\x63\x74\x65\144\40\x6c\151\x6e\x6b\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\x74\x65\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

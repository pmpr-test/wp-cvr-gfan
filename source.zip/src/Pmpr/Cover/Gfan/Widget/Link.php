<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fa3e81             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Link extends Common { public function __construct() { parent::__construct(__("\114\151\x6e\153\163", PR__CVR__GFAN), __("\104\151\163\160\154\141\171\x20\x74\x68\145\x20\x73\145\x6c\x65\x63\164\145\x64\x20\x6c\x69\156\x6b\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

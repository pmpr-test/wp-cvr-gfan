<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e55ba2d879             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\x69\x6e\153\163", PR__CVR__GFAN), __("\104\151\163\x70\x6c\141\171\x20\164\150\145\x20\163\x65\154\x65\143\164\145\x64\40\x6c\151\156\153\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\145\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

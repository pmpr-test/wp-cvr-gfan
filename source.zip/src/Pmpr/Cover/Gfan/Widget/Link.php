<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db317e4fd6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\163", PR__CVR__GFAN), __("\104\151\x73\x70\154\x61\171\40\x74\x68\x65\40\163\x65\x6c\x65\x63\164\x65\x64\x20\154\151\x6e\x6b\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\x74\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

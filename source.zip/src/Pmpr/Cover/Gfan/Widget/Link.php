<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b71b13fa3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\151\156\153\x73", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\141\x79\x20\x74\x68\x65\x20\163\x65\x6c\145\143\x74\x65\x64\x20\154\x69\156\x6b\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\155\163", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

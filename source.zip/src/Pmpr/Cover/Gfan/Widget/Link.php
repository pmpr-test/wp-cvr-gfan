<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b07f57a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\114\151\x6e\153\x73", PR__CVR__GFAN), __("\104\x69\x73\x70\154\141\171\40\164\150\x65\x20\163\145\154\145\143\164\x65\144\x20\x6c\x69\156\153\163\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\x65\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

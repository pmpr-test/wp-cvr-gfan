<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed814b7f6f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\151\x6e\153\163", PR__CVR__GFAN), __("\104\151\163\x70\154\141\171\x20\164\x68\x65\x20\x73\145\154\145\143\x74\x65\x64\40\x6c\x69\x6e\x6b\x73\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\x49\164\x65\155\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

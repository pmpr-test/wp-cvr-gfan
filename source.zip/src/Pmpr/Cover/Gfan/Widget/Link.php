<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8d36f94             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Link extends Widget { public function __construct() { parent::__construct(__("\x4c\151\x6e\x6b\163", PR__CVR__GFAN), __("\104\x69\163\160\x6c\141\171\x20\x74\x68\145\40\x73\145\154\x65\143\x74\x65\144\x20\x6c\151\x6e\153\163\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::qwumqqyuasyskkkc)->gswweykyogmsyawy(__("\111\164\145\x6d\x73", PR__CVR__GFAN))->ukqywcsoogkyoaoa()); } }

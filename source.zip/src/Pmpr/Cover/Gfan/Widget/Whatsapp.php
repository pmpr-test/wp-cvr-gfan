<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cff5cccf             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\x61\x74\x73\x61\x70\x70", PR__CVR__GFAN), __("\x44\x69\163\x70\x6c\x61\x79\x20\164\150\145\40\x77\x68\141\164\163\141\x70\160\x20\154\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\137\x63\x6f\x6e\164\x61\x63\x74\137\151\156\146\157\162\155\141\x74\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\163\141\160\160", PR__CVR__GFAN))); } }

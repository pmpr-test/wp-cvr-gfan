<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e5505b05c1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\x61\x74\x73\141\x70\x70", PR__CVR__GFAN), __("\104\x69\163\160\x6c\x61\171\40\x74\150\x65\40\x77\150\141\x74\163\141\x70\x70\40\x6c\x69\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\x5f\x63\157\156\x74\141\x63\x74\x5f\x69\156\x66\157\x72\155\141\x74\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\x74\163\141\160\160", PR__CVR__GFAN))); } }

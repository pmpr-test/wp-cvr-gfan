<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b07f57a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\x61\x74\163\141\160\x70", PR__CVR__GFAN), __("\x44\x69\163\160\154\x61\171\x20\x74\150\145\x20\167\x68\x61\164\x73\141\x70\x70\40\x6c\151\x6e\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\x6f\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\164\137\143\x6f\156\x74\141\x63\164\x5f\x69\x6e\x66\157\162\155\141\x74\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\x61\x74\163\x61\x70\x70", PR__CVR__GFAN))); } }

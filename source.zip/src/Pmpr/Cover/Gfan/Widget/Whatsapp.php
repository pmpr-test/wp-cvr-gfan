<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712486a20330             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\141\x74\x73\141\160\x70", PR__CVR__GFAN), __("\x44\151\163\160\x6c\x61\171\40\x74\150\145\x20\167\150\141\x74\x73\x61\160\x70\x20\x6c\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\150\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\164\137\143\x6f\156\x74\x61\143\164\x5f\151\x6e\x66\157\162\155\141\164\151\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\x74\163\141\160\x70", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e5f48af89b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\x61\164\x73\x61\160\x70", PR__CVR__GFAN), __("\x44\151\163\x70\x6c\x61\171\40\164\150\x65\40\x77\x68\141\x74\x73\141\x70\160\40\x6c\151\156\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\x5f\x63\157\156\x74\x61\x63\x74\137\151\x6e\x66\x6f\x72\155\141\164\x69\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\164\x73\141\160\x70", PR__CVR__GFAN))); } }

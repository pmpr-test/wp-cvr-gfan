<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dae97375ea             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\164\163\141\x70\x70", PR__CVR__GFAN), __("\104\151\x73\160\154\x61\x79\x20\x74\x68\145\x20\167\x68\141\x74\163\141\x70\160\40\x6c\x69\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\x6f\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\137\143\x6f\156\x74\x61\x63\x74\x5f\x69\156\x66\x6f\x72\155\x61\164\x69\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\164\163\141\160\160", PR__CVR__GFAN))); } }

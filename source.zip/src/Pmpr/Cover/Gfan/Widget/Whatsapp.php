<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e770a35a6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\x61\164\x73\141\x70\x70", PR__CVR__GFAN), __("\x44\151\163\x70\154\141\171\x20\x74\150\x65\x20\167\150\x61\164\163\141\x70\160\x20\x6c\151\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\x5f\x63\157\x6e\164\x61\x63\164\x5f\151\156\x66\157\162\155\x61\x74\151\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\164\163\141\160\x70", PR__CVR__GFAN))); } }

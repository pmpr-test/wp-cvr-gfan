<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b71b13fa3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\164\163\141\x70\x70", PR__CVR__GFAN), __("\x44\x69\x73\x70\x6c\x61\x79\x20\164\x68\x65\x20\x77\150\141\164\163\x61\x70\160\x20\x6c\x69\156\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\164\137\x63\x6f\x6e\164\x61\x63\164\137\x69\156\146\x6f\162\155\x61\164\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\x61\164\x73\141\x70\x70", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670e600056ce2             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\x61\x74\x73\x61\x70\x70", PR__CVR__GFAN), __("\104\151\x73\160\154\x61\171\x20\x74\x68\145\x20\167\x68\141\164\x73\x61\x70\160\x20\x6c\x69\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\x65\x74\137\143\x6f\x6e\x74\141\x63\x74\x5f\x69\x6e\x66\x6f\x72\x6d\141\164\x69\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\x73\x61\x70\x70", PR__CVR__GFAN))); } }

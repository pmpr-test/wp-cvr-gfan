<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dae380e6d9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\x68\x61\164\x73\x61\160\160", PR__CVR__GFAN), __("\x44\151\x73\x70\x6c\x61\x79\40\x74\x68\145\x20\x77\x68\x61\x74\163\141\160\160\x20\154\151\156\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\137\x63\157\x6e\x74\x61\143\164\137\151\x6e\146\157\x72\155\141\x74\x69\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\141\x74\x73\141\160\160", PR__CVR__GFAN))); } }

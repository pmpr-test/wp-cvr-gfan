<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051743eccac             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\150\141\x74\163\141\x70\x70", PR__CVR__GFAN), __("\x44\151\x73\160\x6c\x61\171\x20\x74\150\145\x20\x77\150\141\164\x73\141\160\160\x20\x6c\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\x5f\143\157\x6e\164\141\x63\164\137\151\x6e\x66\157\x72\x6d\141\164\x69\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\150\141\x74\163\x61\x70\160", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe2b7e45             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\x61\x74\x73\x61\x70\160", PR__CVR__GFAN), __("\x44\x69\163\160\x6c\141\x79\x20\x74\x68\x65\40\x77\150\x61\164\x73\141\160\160\40\154\151\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\164\x5f\143\157\156\x74\x61\143\164\x5f\x69\x6e\x66\x6f\162\155\x61\x74\151\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\x74\x73\x61\x70\x70", PR__CVR__GFAN))); } }

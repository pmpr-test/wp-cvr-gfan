<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b9b5ea101             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\150\141\164\163\x61\160\x70", PR__CVR__GFAN), __("\104\x69\x73\160\x6c\x61\x79\x20\164\x68\x65\x20\167\150\141\x74\163\x61\x70\160\40\154\151\x6e\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\145\x74\137\x63\x6f\156\x74\141\x63\x74\x5f\151\156\146\157\162\x6d\x61\164\x69\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\x68\141\164\163\x61\x70\160", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc062457d1             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\141\x74\163\141\x70\160", PR__CVR__GFAN), __("\104\x69\x73\160\154\x61\171\x20\x74\x68\145\40\x77\x68\141\x74\x73\141\x70\x70\x20\154\151\156\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\164\x5f\x63\157\x6e\164\141\143\x74\x5f\x69\156\x66\x6f\162\x6d\141\164\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\x57\x68\141\x74\163\141\160\160", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db14a60dca             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\150\141\x74\163\x61\x70\160", PR__CVR__GFAN), __("\104\x69\163\160\x6c\141\171\x20\x74\150\145\40\167\x68\x61\164\x73\141\x70\x70\x20\x6c\x69\x6e\x6b\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\x6f\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\x5f\143\157\156\164\141\143\x74\137\151\x6e\146\x6f\162\155\141\164\151\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\163\x61\160\160", PR__CVR__GFAN))); } }

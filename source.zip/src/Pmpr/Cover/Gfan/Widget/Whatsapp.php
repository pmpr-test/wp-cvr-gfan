<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bdd8b9b             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\150\141\164\163\141\160\x70", PR__CVR__GFAN), __("\104\151\x73\160\154\x61\171\40\164\150\x65\x20\x77\x68\141\164\163\x61\x70\160\x20\154\151\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\x6f\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\x74\137\x63\x6f\x6e\x74\x61\x63\164\x5f\151\x6e\x66\x6f\162\155\x61\164\x69\x6f\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\164\163\141\160\x70", PR__CVR__GFAN))); } }

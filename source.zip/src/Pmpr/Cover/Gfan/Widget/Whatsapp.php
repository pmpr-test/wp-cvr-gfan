<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed856b7fad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\150\141\164\x73\x61\160\x70", PR__CVR__GFAN), __("\x44\151\163\160\154\x61\171\40\164\150\x65\40\167\x68\141\164\x73\x61\160\x70\x20\x6c\151\156\153\x2e", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\x6e\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\x67\145\164\x5f\143\x6f\156\164\141\x63\164\137\151\156\x66\157\x72\x6d\141\x74\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\164\163\141\x70\x70", PR__CVR__GFAN))); } }

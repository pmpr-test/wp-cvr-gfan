<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b6abb780d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\127\150\141\164\163\141\160\160", PR__CVR__GFAN), __("\x44\x69\163\160\x6c\x61\x79\40\164\x68\145\40\x77\150\141\x74\x73\x61\160\x70\x20\154\x69\x6e\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\150\157\156\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\137\143\x6f\x6e\x74\x61\143\x74\x5f\x69\x6e\x66\157\x72\155\141\164\x69\157\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\141\x74\x73\141\x70\160", PR__CVR__GFAN))); } }

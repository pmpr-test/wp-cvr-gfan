<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a8d36f94             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Whatsapp extends Widget { public function __construct() { parent::__construct(__("\x57\x68\141\164\163\141\160\160", PR__CVR__GFAN), __("\104\151\163\x70\x6c\141\171\40\x74\x68\x65\40\x77\150\x61\x74\x73\x61\160\160\x20\154\x69\156\153\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\x50\x68\157\156\145", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\137\x63\157\x6e\x74\x61\x63\164\137\151\x6e\146\157\x72\155\x61\164\151\x6f\156", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\x74", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\x74\163\x61\160\x70", PR__CVR__GFAN))); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192950bd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Whatsapp extends Common { public function __construct() { parent::__construct(__("\127\x68\141\164\163\x61\x70\x70", PR__CVR__GFAN), __("\104\x69\x73\160\x6c\x61\x79\x20\164\x68\x65\40\167\x68\141\164\x73\141\x70\x70\40\x6c\x69\x6e\x6b\56", PR__CVR__GFAN)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->mccagaqeagiikkec(Constants::memskaacyikisggk)->gswweykyogmsyawy(__("\120\x68\157\x6e\x65", PR__CVR__GFAN))->acauweqyyugwisqc($this->ocksiywmkyaqseou("\147\x65\x74\x5f\x63\157\156\x74\x61\143\x74\x5f\151\156\x66\x6f\162\x6d\x61\x74\x69\157\x6e", [], [Constants::squoamkioomemiyi => Constants::memskaacyikisggk])))->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\170\164", PR__CVR__GFAN))->eyygsasuqmommkua(__("\127\150\x61\x74\163\141\160\x70", PR__CVR__GFAN))); } }

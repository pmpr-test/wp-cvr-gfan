<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e770a35a6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\147\x66\x61\x6e\x5f\x63\165\x73\164\x6f\155\x69\x7a\x65\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }

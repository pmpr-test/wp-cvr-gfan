<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfb3fb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customizer\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\147\x66\141\x6e\x5f\143\165\163\164\x6f\x6d\151\x7a\x65\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051743eccac             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customizer\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\147\x66\x61\156\137\x63\165\163\x74\157\155\x69\x7a\145\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae192950bd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customizer\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\x67\x66\141\x6e\x5f\x63\165\163\164\157\155\x69\172\x65\x72"; parent::__construct(); } public function yogecqociwgqoscg() { } }

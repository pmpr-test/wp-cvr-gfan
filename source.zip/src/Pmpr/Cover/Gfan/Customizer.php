<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fa3e81             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customizer\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\147\146\x61\x6e\x5f\x63\165\x73\x74\157\155\x69\172\145\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe2b7e45             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Cover\Customize\Customizer as BaseClass; class Customizer extends BaseClass { public function __construct() { $this->id = "\x67\146\141\156\137\143\x75\x73\164\x6f\x6d\151\172\x65\162"; parent::__construct(); } public function yogecqociwgqoscg() { } }

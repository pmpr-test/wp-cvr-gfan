<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670dae380e6d9             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6ee2aeff             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; trait ImageTrait { public function mkcqggisuwuuueqm() : array { return [Constants::qisqmmesuewemeqg => ['crop' => 1, 'width' => 1163, 'height' => 491], Constants::egkuckyqcaygmymg => ['crop' => 1, 'width' => 965, 'height' => 500, 'custom' => 1], Constants::ccgiciqicykuquwc => ['crop' => 1, 'width' => 578, 'height' => 578], Constants::MEDIUM => ['crop' => 1, 'width' => 484, 'height' => 366], Constants::egwoacukmsioosum => ['crop' => 1, 'width' => 276, 'height' => 276], Constants::meugkwqwuyoyeeqs => ['crop' => 1, 'width' => 100, 'height' => 100, 'custom' => 1], Constants::makwgimcquecmkai => ['crop' => 1, 'width' => 80, 'height' => 80, 'custom' => 1], Constants::ouiqqqmuwickywei => ['crop' => 1, 'width' => 30, 'height' => 30, 'custom' => 1]]; } }

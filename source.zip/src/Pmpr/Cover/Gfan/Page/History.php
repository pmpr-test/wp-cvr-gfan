<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051743eccac             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\150\151\163\x74\157\x72\171"; $this->title = __("\x48\151\x73\x74\157\162\x79", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

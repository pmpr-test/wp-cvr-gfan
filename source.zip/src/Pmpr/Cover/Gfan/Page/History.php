<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfb3fb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\x69\x73\x74\x6f\x72\x79"; $this->title = __("\110\151\163\164\157\x72\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

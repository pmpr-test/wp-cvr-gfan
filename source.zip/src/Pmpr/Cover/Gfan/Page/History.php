<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe2b7e45             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class History extends Common { public function __construct() { $this->slug = "\x68\151\163\164\157\162\x79"; $this->title = __("\110\x69\x73\164\157\x72\171", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

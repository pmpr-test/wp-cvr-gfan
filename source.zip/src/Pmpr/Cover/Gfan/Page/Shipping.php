<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae85fa3e81             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\x68\x69\160\x70\x69\156\147"; $this->title = __("\x53\x68\151\x70\160\x69\156\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

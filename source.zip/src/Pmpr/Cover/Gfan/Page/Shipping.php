<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebe2b7e45             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\163\150\x69\x70\160\151\x6e\x67"; $this->title = __("\123\150\x69\160\x70\x69\x6e\147", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

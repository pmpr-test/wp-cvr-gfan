<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67051743eccac             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Shipping extends Common { public function __construct() { $this->slug = "\x73\150\x69\x70\x70\151\x6e\147"; $this->title = __("\x53\150\x69\x70\x70\151\x6e\x67", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

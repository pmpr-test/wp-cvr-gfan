<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e770a35a6             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\x75\141\162\141\x6e\164\x65\x65"; $this->title = __("\107\165\x61\162\141\x6e\164\145\145", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670520dfb3fb3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Page; class Guarantee extends Common { public function __construct() { $this->slug = "\147\165\141\x72\141\156\164\x65\145"; $this->title = __("\x47\165\141\162\141\156\x74\x65\x65", PR__CVR__GFAN); $this->isPrivate = false; parent::__construct(); } }

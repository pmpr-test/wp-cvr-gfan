<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6ee2aeff             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Gfan\Navigation\Walker; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Common\Cover\Navigation\Walker; class Aside extends Walker { public function __construct() { $this->seqmucuwuueuqekq(['class' => 'list-unstyled collapse ml-3 border-none']); } public function ksosuqqukyweqiao($iwywmkygwewiamwm, $igqsaukqcqscimok, $kkisyguyosoyymqs) { if ($kkisyguyosoyymqs) { $swqimwqeweekeusq = $this->caokeucsksukesyo()->wgqqgewcmcemoewo(); $cgceiiqaamkmsaim = $swqimwqeweekeusq->cuoygaaeqeqcuggu(IconInterface::ckqgusoqoosqqwyo, ['class' => 'icon-1x icon-dark rotate-180']); $cgceiiqaamkmsaim = $swqimwqeweekeusq->yuawgssgauywkiia($cgceiiqaamkmsaim, "#{$this->amqewiesyqeqiuai()}", ['class' => 'rotate-on-show', 'data-toggle' => 'collapse', 'aria-expanded' => 'false']); $iwywmkygwewiamwm = $swqimwqeweekeusq->gmqyuaqwgiayskei($iwywmkygwewiamwm . $cgceiiqaamkmsaim, ['class' => 'd-flex justify-content-between']); } return $iwywmkygwewiamwm; } }

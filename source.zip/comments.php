<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670db14a60dca             |
    |_______________________________________|
*/
 pmpr_do_action("\162\145\x6e\x64\x65\x72\x5f\x63\x6f\x6d\x6d\145\156\164\x73");

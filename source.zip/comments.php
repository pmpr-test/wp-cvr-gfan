<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6712b6abb780d             |
    |_______________________________________|
*/
 pmpr_do_action("\x72\x65\x6e\x64\x65\x72\x5f\x63\x6f\155\155\x65\x6e\x74\x73");
